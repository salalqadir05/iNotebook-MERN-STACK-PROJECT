import About from "./components/About";
import Home from "./components/Home";
import NoteState from "./components/context/notes/NoteState";
import Navbar from "./components/Navbar";
import Login from "./components/Login";
import Alert from "./components/Alert";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SignUp from "./components/SignUp";
import { useState } from "react";
// import Alert from "./components/Alert";

function App() {

const [message, setmessage] = useState(null)
const [type, settype] = useState(null)


const showmessage = () =>{
const m1 =   
setmessage("Loged In Successfully")
return m1
}

const showtype = () =>{
 const t1 = settype("success")
return t1;  
}
  
  return (
    <div className="App">
    <NoteState>
    <Router>
    <Navbar />
    {/* <Alert  showmessage={showmessage} showtype={showtype} /> */}

            <Routes>
             <Route  exact path="/"   element={
             <Home   />
             }></Route>
            <Route  exact path="/About"   element={
             <About />
             }></Route>
                 <Route  exact path="/Login"   element={
             <Login />
             }></Route>
                              <Route  exact path="/Signup"   element={
             <SignUp />
             }></Route>
            </Routes>
      </Router>
      </NoteState>
    </div>
  );
}

export default App;
