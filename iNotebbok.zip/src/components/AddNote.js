import React,{useContext, useState} from 'react'
import noteContext from './context/notes/noteContext'
const AddNote = () => {

const context = useContext(noteContext)
const {Addnotes} = context;
const [note,setNote] = useState({title:"",Decription:"",tag:""})
const HandleCheck =  ( e) =>{
    console.log(note.title,note.Decription,note.tag);
    e.preventDefault();
    Addnotes(note.title,note.Decription,note.tag);
    setNote({title:"",Decription:"",tag:""});
// AddNote(note);
}
const OnChange =(e)=>{
setNote({...note,[e.target.name]:e.target.value})
} 
    return (
    <div className='container my-2'>
      <h1> Add a Notes</h1>
      <div className="mb-3">
        <label htmlFor="exampleFormControlInput1" className="form-label">Title</label>
        <input type="text" className="form-control" id="title" name='title' value={note.title} onChange={OnChange} placeholder="Title for your Note" minLength={5} required />
      </div>
      <div className="mb-3">
        <label htmlFor="tag" className="form-label">Enter Tag</label>
        <input type="text" className="form-control" id="tag" name='tag' value={note.tag} onChange={OnChange}  minLength={5} required></input>
      </div>
      <div className="mb-3">
        <label htmlFor="exampleFormControlTextarea1" className="form-label">Your Note</label>
        <textarea className="form-control" id="Decription" name='Decription' value={note.Decription} onChange={OnChange} rows="3" minLength={5} required></textarea>
      </div>

      <button disabled={note.title.length  < 5 || note.Decription.length  < 5} type="button" className="btn btn-primary" onClick={HandleCheck}>Add Note</button>
    </div>
  )
}

export default AddNote
