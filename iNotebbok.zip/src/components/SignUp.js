import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
const SignUp = () => {
    const [creaditional,setcreaditional] = useState({name:"",email:"",password:"",cpassword:""});
     const history = useNavigate();

        const handlesubmit = async(e) =>
        {
            // console.log("hello World")
            e.preventDefault();
          const {name,email ,password} = creaditional;
            const host = "http://localhost:5000";

            const response = await fetch(`${host}/api/auth/createuser`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body:JSON.stringify({name,email,password})
                   });
            const json = await response.json();
            console.log(json);
            if(json.success)
            {
                localStorage.setItem("token",json.authtoken)
                history("/Login");

            }
            else {
                alert("did not log in ");
            }
        }
        
    const OnChange =(e)=>{
        setcreaditional({...creaditional,[e.target.name]:e.target.value})
        
        } ;
    return (
        <div className='container my-3'>
        <form onSubmit={handlesubmit}>
            <h2 className='d-flex justify-content-center my-4'>Enter Your Details of Login</h2>
            <div className="mb-3">
                <label htmlFor="name" className="form-label">Name</label>
                <input type="text" className="form-control" onChange={OnChange} name='name'  id="name" placeholder="Enter Your Name" />
            </div>
            <div className="mb-3">
                <label htmlFor="email" className="form-label">Email address</label>
                <input type="email" className="form-control"  onChange={OnChange} name='email'  id="email" placeholder="Enter Your Email" />
            </div>
            <div className="mb-3">
                <label htmlFor="password" className="form-label"> Password </label>
                <input type='password' className="form-control"  onChange={OnChange} id="password"  name='password'  placeholder='Enter Your Password' />
            </div>
            
            <div className="mb-3">
                <label htmlFor="password" className="form-label">Confirm  Password </label>
                <input type='password' className="form-control"  onChange={OnChange} id="cpassword" name='cpassword'  placeholder='Confirm Your Password' />
            </div>
            <button  type="submit" className="btn btn-primary" >Submit</button>
</form>
        </div>
    )
}


export default SignUp