import React, { useContext,useEffect,useState,useRef } from 'react'
import noteContext from './context/notes/noteContext';
import Noteitem from './Noteitem';
import AddNote from './AddNote.js';
import { Navigate, useNavigate } from 'react-router-dom';

function Notes()
{
    const context = useContext(noteContext);
    const {notes,getallnotes,editnotes}= context;
  const navigate = useNavigate()
        useEffect(()=>{
          // eslint-disable-next-line
          console.log(localStorage.getItem('token'))
          if(localStorage.getItem('token'))
          {
            getallnotes();

          }
          else{
            navigate("/Login");
          }
        },[getallnotes]);
    const ref = useRef(null);
    const refclose = useRef(null);

    const [note,setNote] = useState({id:"",etitle:"",eDecription:"",etag:""})
    const HandleCheck =  ( e) =>{
      editnotes(note.id,note.etitle,note.eDecription,note.etag)
      ref.current.click();
    }
    const OnChange =(e)=>{
    setNote({...note,[e.target.name]:e.target.value})
    
    } ;
   
    const  updatenotes =(currentNote) =>{
    ref.current.click();
    setNote({id:currentNote._id,etitle: currentNote.title ,eDecription:currentNote.Decription,etag:currentNote.tag});
   

   }

 return (
<>
  <div className='container my-3'>
    <AddNote />
<button ref={ref} type="button" className="btn btn-primary d-none" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Edit Modal
</button>

<div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div className="modal-dialog">
    <div className="modal-content">
      <div className="modal-header">
        <h1 className="modal-title fs-5" id="exampleModalLabel">Edit Your Note</h1>
        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div className="modal-body">
      <div className='container my-2'>
      <h1> Add a Note</h1>
      <div className="mb-3">
        <label htmlFor="etitle" className="form-label">Title</label>
        <input type="text" className="form-control" id="etitle" name='etitle' value={note.etitle} onChange={OnChange} placeholder="Title for your Note" minLength={5} required />
      </div>
      <div className="mb-3">
        <label htmlFor="etag" className="form-label">Enter Tag</label>
        <input type="text" className="form-control"  id="etag" name='etag' value={note.etag} onChange={OnChange} minLength={5} required ></input>
      </div>
      <div className="mb-3">
        <label htmlFor="Decription" className="form-label">Your Note</label>
        <textarea className="form-control" id="eDecription"  name='eDecription' value={note.eDecription} onChange={OnChange} rows="3"  minLength={5} required ></textarea>
      </div>

    </div>
      </div>
      <div className="modal-footer">
        <button  ref={refclose} type="button"  className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button disabled={note.etitle.length  < 5 || note.eDecription.length  < 5} type="button" className="btn btn-primary" onClick={HandleCheck}>Edit Notes</button>

      </div>
    </div>
  </div>
</div>
  <div className='row'>
  <h2>Your Notes</h2>
  <div className='container'>  {notes.length === 0 && "Please Add the Notes You donot have any notes  "}
  </div>

  {notes.map((notes)=>{return (<Noteitem notes={notes} updatenotes={updatenotes}  key={notes._id} /> )})}
  </div>
  </div>
</>
)
};


export default Notes