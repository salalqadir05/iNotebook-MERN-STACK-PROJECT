import React from 'react'


const Alert = (props) => {
   const message  = props.showmessage();
   const type = props.showtype();
    const capitalize = (word) =>{
        const lower = word.toLowerCase();
        return lower.charAt(0).toUpperCase() + lower.slice(1);
    }
    return (
        <>
        <div className={`alert alert-${type}`} role="alert">
        {message}
        </div>
        </>
    )
}

export default Alert
