import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
const Login = (props) => {
    const [creaditional,setcreaditional] = useState({email:"",password:""});
     const history = useNavigate();

        const handlesubmit = async(e) =>
        {
            // console.log("hello World")
            e.preventDefault();
          
            const host = "http://localhost:5000";

            const response = await fetch(`${host}/api/auth/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body:JSON.stringify({email : creaditional.email ,password : creaditional.password})
                   });
            const json = await response.json();
            console.log(json);
            if(json.success)
            {
                localStorage.setItem("token",json.authtoken)
                history("/");
                // props.showAlert("Your have Successfully Loged in  ","success")


            }
            else {
                alert ("did not Loged in")
                // props.showAlert("Your Creaditional are Wrong ! Please Check it ","danger")/
            }
        }
        
    const OnChange =(e)=>{
        setcreaditional({...creaditional,[e.target.name]:e.target.value})
        
        } ;
    return (
        <div className='container my-3'>
        <form onSubmit={handlesubmit}>
            <h2 className='d-flex justify-content-center my-4'>Enter Your Details of Login</h2>
            <div className="mb-3">
                <label htmlFor="email" className="form-label">Email address</label>
                <input type="email" className="form-control" value={creaditional.email} onChange={OnChange} name='email'  id="email" placeholder="Enter Your Email" />
            </div>
            <div className="mb-3">
                <label htmlFor="password" className="form-label">Enter Your Password </label>
                <input type='password' className="form-control"  onChange={OnChange} id="password" value={creaditional.password} name='password' autoComplete="on" placeholder='Enter Your Password'></input>
            </div>
            <button  type="submit" className="btn btn-primary" >Submit</button>
</form>
        </div>
    )
}


export default Login
