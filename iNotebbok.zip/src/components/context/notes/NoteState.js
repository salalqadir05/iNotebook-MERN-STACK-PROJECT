import { useState } from "react";
import NoteContext from "./noteContext";

const NoteState = (props) => {
    const host = "http://localhost:5000";
    const noteintial = [];
    const getallnotes = async () => {
        const response = await fetch(`${host}/api/notes/fetchallnotes`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "auth-token": localStorage.getItem('token')
            }
        });
        const json = await response.json();
        setNotes(json);


    }
    const [notes, setNotes] = useState(noteintial);
    const Addnotes = async (title, Decription, tag) => {
        const host = "http://localhost:5000";

        const response = await fetch(`${host}/api/notes/addnotes`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "auth-token": localStorage.getItem('token')
            },
            body:JSON.stringify({title,Decription,tag})
               });
        const json = await response.json();
        console.log(json);
        setNotes(notes.concat(json));
    }
    const deleteNote = async (id) => {
        const host = "http://localhost:5000";

        const response = await fetch(`${host}/api/notes/deletenote/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "auth-token": localStorage.getItem('token')
            }
        });
        const json = await response.json();
        const newNotes = notes.filter((notes) => { return notes._id !== id });
        setNotes(newNotes);



    }

    const editnotes = async(id,title,Decription,tag) =>{
        const host = "http://localhost:5000";

        const response = await fetch(`${host}/api/notes/updatenote/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "auth-token": localStorage.getItem('token')
            },
            body:JSON.stringify({title,Decription,tag})

        });
        const json = await response.json();
        let newNote = JSON.parse(JSON.stringify(notes))

        for (let index = 0; index < notes.length; index++) {
            const element = newNote[index];
            if(element.id === id )
            {
                newNote[index].title = title ;
                newNote[index].Decription = Decription ;
                newNote[index].tag = tag ;
                break;

            }
            
        }

    setNotes(newNote)

    }
    return (
        <NoteContext.Provider value={{ notes, Addnotes, deleteNote, getallnotes,editnotes }}>
            {props.children}
        </NoteContext.Provider>
    )


};

export default NoteState;