const connectTomongo = require("./db.js");
const express = require('express');
const auth = require('./routes/auth.js');
const notes = require('./routes/notes.js');
const  cors = require('cors')
const app = express()
app.use(cors())
app.use(express.json());

connectTomongo()

const port = 5000;

app.use('/api/auth',auth);
app.use("/api/notes",notes);


app.listen(port, () => {
  console.log(`iNotebook app listening on port ${port}`)
})