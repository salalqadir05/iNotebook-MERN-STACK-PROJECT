const express = require('express')
const router = express.Router();
var fetchuser = require('../Middleware/fetchuser');
const { body, validationResult } = require('express-validator');
const Note = require("../Models/Note");
// get data from data base fetch all the notes 
router.get('/fetchallnotes', fetchuser, async (req, res) => {
   try {
       const notes = await Note.find({ user: req.user.id });
       res.json(notes)
   } catch (error) {
       console.error(error.message);
       res.status(500).send("Internal Server Error");
   }
})

// insert data from data base of the notes 
router.post('/addnotes',[
   body('title',"Enter the valid title and its minimum 3 characters").isLength({ min: 3 }),
   body('Decription',"Description must atleast 5 charaters").isLength({ min: 5 })

],fetchuser,async(req,res)=>{

   try {
      const {title,Decription,tag} = req.body;
      // console.log(  `req.body`, req.body.title);
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
   
      const notes = new Note({
            title,Decription,tag ,user : req.user.id
                  }
      )
      console.log(notes)
      const notesave =await notes.save();
      res.json(notesave);
   } catch (error) {
      console.error(error.message);
      res.status(500).send("Internal Server Error");
  }

});

router.put('/updatenote/:id',fetchuser,async(req,res)=>{

   const {title,Decription,tag} = req.body;

try {
   let newnotes = {};
if(title){newnotes.title = title}
   if(Decription){newnotes.Decription = Decription}
if(tag){newnotes.tag = tag}

let note = await Note.findById(req.params.id)

if(note.user.toString() !== req.user.id)
{
   return res.status(401).send("Not Allowed");
}

note = await Note.findByIdAndUpdate(req.params.id ,{$set:newnotes},{new:true})
res.json({note})   
} catch (error) {
   console.error(error.message);
   res.status(500).send("Internal Server Error");
}


})



router.delete('/deletenote/:id',fetchuser,async(req,res)=>{

   const {title,Decription,tag} = req.body;

try {
let note = await Note.findById(req.params.id)

if(note.user.toString() !== req.user.id)
{
   return res.status(401).send("Not Allowed");
}

note = await Note.findByIdAndDelete(req.params.id )
res.json("successfully deleted")   
} catch (error) {
   console.error(error.message);
   res.status(500).send("Internal Server Error");
}


})


module.exports = router;