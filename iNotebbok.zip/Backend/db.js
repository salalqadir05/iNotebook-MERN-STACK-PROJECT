const mongoURi = "mongodb://127.0.0.1:27017/inotebook";
const mongoose = require("mongoose");

// mongodb://localhost:27017
connectTomongo = async() =>{
try {
    const con =  await  mongoose.connect(mongoURi);
    console.log(`mongodb is connected : ${con.connection.host}`)
}
catch(err)
{
    console.error(err);
}
};
 

module.exports = connectTomongo;
